insert into prezzi (tipo_film, tipo_biglietto, prezzo) values ('2D', 'NORMALE', 8);
insert into prezzi (tipo_film, tipo_biglietto, prezzo) values ('2D', 'RIDOTTO', 6);
insert into prezzi (tipo_film, tipo_biglietto, prezzo) values ('2D', 'MILITARI', 6);
insert into prezzi (tipo_film, tipo_biglietto, prezzo) values ('2D', 'DISABILI', 6);
insert into prezzi (tipo_film, tipo_biglietto, prezzo) values ('3D', 'NORMALE', 10);
insert into prezzi (tipo_film, tipo_biglietto, prezzo) values ('3D', 'RIDOTTO', 8);
insert into prezzi (tipo_film, tipo_biglietto, prezzo) values ('3D', 'MILITARI', 8);
insert into prezzi (tipo_film, tipo_biglietto, prezzo) values ('3D', 'DISABILI', 8);
