INSERT INTO SALA (nome_sala, descrizione,larghezza,lunghezza) VALUES ('D','sala grande, capacit� 166',16,16); 



INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),1,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),2,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),3,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,1);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),4,14);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,0);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,1);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,14);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),5,15);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,0);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,1);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,14);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),6,15);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),7,0);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),7,1);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),7,14);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),7,15);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,0);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,1);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,14);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),8,15);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,0);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),9,15);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,0);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),10,15);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,0);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),11,15);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,1);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,2);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,13);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),13,14);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,1);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,2);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,13);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),14,14);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,1);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,2);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,3);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,4);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,5);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,6);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,7);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,8);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,9);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,10);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,11);
INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,12);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,13);

INSERT INTO POSTO (id_sala,riga,colonna) VALUES ((SELECT id_sala FROM SALA WHERE nome_sala='D'),15,14);
